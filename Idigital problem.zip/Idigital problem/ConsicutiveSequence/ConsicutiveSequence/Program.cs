﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsicutiveSequence
{
    /* Qus:- Write a program to find the length of the longest consecutive 
             elements sequence from a given unsorted array of integers.
             Sample array: [49, 1, 3, 200, 2, 4, 70, 5]
             The longest consecutive elements sequence is [1, 2, 3, 4, 5],
             therefore the program will return its length 5.*/
    class Program
    {
         static void Main(string[] args)
         {
             Console.WriteLine("Enter the lenght of array:");
             int n = int.Parse(Console.ReadLine());
             int[] array = new int[n];

             Console.WriteLine("Enter array elements:");
             for(int i = 0; i < array.Length; i++)
             {
                 array[i] = int.Parse(Console.ReadLine());
             }
             int ans = 0, count = 0;
             Array.Sort(array);
             for (int i = 0; i <array.Length; i++)
             {
                 if (i >0 && array[i] == array[i - 1] + 1)
                     count++;
                 else
                 count = 1;

                 ans = Math.Max(ans, count);
             }
              Console.WriteLine("Length of longest consicutive number: " +ans);
             Console.ReadKey();
         }
     }
}

/*
 *********************
       Algorithm:
 **********************

1=> Create an empty array of integer with n-length.
2=> Insert all n-elements into the array.
3=> Do following for every element array[i]
4=> Check if this element is the starting point of a subsequence. To check this, simply look for (array[i] – 1) in the array, if not found, then this is the first element a subsequence.
5=> If this element is the first element, then count the number of elements in the consecutive starting with this element. Iterate from array[i] + 1 till the last element that can be found.
6=> If the count is more than the previous longest subsequence found, then update this.
7=> Finaly print the updated count at the end
 */

/*
 *********************
  Complexity Analysis:
 * ******************
Time complexity: O(nLogn).
Time to sort the array is O(nlogn).
Auxiliary space : O(1).
As no extra space is needed.
 */
