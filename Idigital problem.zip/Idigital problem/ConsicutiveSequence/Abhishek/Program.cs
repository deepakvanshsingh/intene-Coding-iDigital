﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abhishek
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter how many values you want to enter into vector");

            try
            {
                int length = Convert.ToInt32(Console.ReadLine());
                int[] Vector = new int[length];
                Console.WriteLine("Enter the values into the vector");
                for (int i = 0; i < length; i++)
                {
                    Vector[i] = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine("Enter the value of K");
                int k = Convert.ToInt32(Console.ReadLine());

                int TotalSubsets = countSubsets(Vector, k);
                Console.WriteLine("Total Subsets are " + TotalSubsets);
                Console.ReadKey();
            }
            catch (Exception)
            {
                Console.WriteLine("Exception occured");
            }
        }
        public static int countSubsets(int[] nums, int k)
        {

            {
                Array.Sort(nums);
                int count = 0;

                for (int lo = 0, hi = nums.Length - 1; lo <= hi;)
                {

                    if (nums[lo] + nums[hi] > k)
                    {
                        hi--;
                    }
                    else
                    {
                        count += 1 << (hi - lo);
                        lo++;
                    }
                }
                return count;
            }


        }
    }
}
