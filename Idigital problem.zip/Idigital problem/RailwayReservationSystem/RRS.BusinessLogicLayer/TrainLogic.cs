﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RRS.BusinessLogicLayer;
using RRS.EntityLayer;
using RRS.ExceptionLayer;
using RRS.DataaccessLayer;

namespace RRS.BusinessLogicLayer
{
    public class TrainLogic
    {
        /*************************input validation******************************/
        public static bool CheckTrain(Trains train)
        {
            StringBuilder error = new StringBuilder();
            bool flag = false;
            try
            {
                if (train.TrainNumber >0)
                    flag = true;
                else
                    error.Append("Error: Train number can't be like this");

                if (train.SourceCity.Length > 0)
                {
                    if (flag == false)
                        throw (new TrainExceptions(error.ToString()));
                    flag = true;
                }
                else
                {
                    error.Append("Error: Source city can't be empty:");
                    flag = false;
                    throw (new TrainExceptions(error.ToString()));
                    
                }
                if (train.DestinationCity.Length > 0)
                {
                    if (flag == false)
                        throw (new TrainExceptions(error.ToString()));
                    flag = true;
                }
                else
                {
                    error.Append("Error: destination city can't be empty:");
                    flag = false;
                    throw (new TrainExceptions(error.ToString()));
                }
                if ((train.Date.ToString()).Length>0)
                {
                    if (flag == false)
                        throw (new TrainExceptions(error.ToString()));
                    flag = true;
                }
                else
                {
                    error.Append("Error: Date has inccorect formate!!:");
                    flag = false;
                    throw (new TrainExceptions(error.ToString()));
                }
                if (train.ArrivalTime.Length > 0)
                {
                    if (flag == false)
                        throw (new TrainExceptions(error.ToString()));
                    flag = true;
                }
                else
                {
                    error.Append("Error: Arrival time has inccorect formate!!:");
                    flag = false;
                    throw (new TrainExceptions(error.ToString()));
                }
                if (train.DepartureTime.Length > 0)
                {
                    if (flag == false)
                        throw (new TrainExceptions(error.ToString()));
                    flag = true;
                }
                else
                {
                    error.Append("Error: Departure time has inccorect formate!!:");
                    flag = false;
                    throw (new TrainExceptions(error.ToString()));
                }
                if (train.StationName.Length > 0)
                {
                    if (flag == false)
                        throw (new TrainExceptions(error.ToString()));
                    flag = true;
                }
                else
                {
                    error.Append("Error: Station name can't be empty!!:");
                    flag = false;
                    throw (new TrainExceptions(error.ToString()));
                }
            }
            catch (TrainExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.ReadKey();
            return flag;
        }

        /******************First validating data then sending to DAL layer***********************/
        public static bool AddTrain_BLL(Trains train)
        {
            if (CheckTrain(train))
            {
                TrainDatabase.TrainListSerialize(train);
                return true;
            }
            else
            {
                return false;
            }
        }

        public static List<Trains> GetAllTrains_BLL()
        {
           return TrainDatabase.TrainListDeSerialize();
        }
    }
}
