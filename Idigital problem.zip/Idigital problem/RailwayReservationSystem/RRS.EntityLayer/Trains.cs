﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RRS.EntityLayer
{
    /****************Train entity attribute***************/
    [Serializable]
    public class Trains
    {
        public int TrainNumber { get; set; }
        public string SourceCity{ get; set; } 
        public string DestinationCity { get; set; }
        public DateTime Date { get; set; }
        public string ArrivalTime { get; set; }
        public string DepartureTime { get; set; }
        public string StationName { get; set; }

    }
}
