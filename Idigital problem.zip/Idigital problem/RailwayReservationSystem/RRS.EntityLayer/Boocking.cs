﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RRS.EntityLayer
{
    [Serializable]
   public class Boocking
    {
        public int Id { get; set; }
        public int TrainNumber { get; set; }
        public string PessangerName { get; set; }
        public char Class { get; set; }
    }
}
