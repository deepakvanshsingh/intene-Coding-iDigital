﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RRS.EntityLayer;
using RRS.ExceptionLayer;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace RRS.DataaccessLayer
{
    public class TrainDatabase
    {
        public static List<Trains> trains = new List<Trains>();
        public static string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

        /************************************** Seralizing train Data **************************************************/
        public static void TrainListSerialize(Trains train)
        {
            /************Logic for automaticly create folder and file****************/
            string path = "";
            if (!Directory.Exists(desktopPath + @"\Railway Reservation System"))
            {
                System.IO.Directory.CreateDirectory(desktopPath + @"\Railway Reservation System");
                path = desktopPath + @"\Railway Reservation System\Trains.txt";
                //Console.WriteLine("Created location:" + path);
            }

            /*************************************/

            path = desktopPath + @"\Railway Reservation System\Trains.txt";

            BinaryFormatter formatter = new BinaryFormatter();
            try
            {
                if (File.Exists(path))
                {
                    trains = TrainListDeSerialize();    
                }
               
                    trains.Add(train);
                    Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
                    formatter.Serialize(stream, trains);
                    stream.Close(); 
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("ERROR: File Not Exixt In Current Context!!:");
            }
            catch (Exception fileException)
            {
                Console.WriteLine(fileException.Message);
            }
        }

        public static List<Trains> TrainListDeSerialize()
        {
            List<Trains> train = null;
            try
            {
                string path = desktopPath + @"\Railway Reservation System\Trains.txt";
                if (File.Exists(path))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
                    train = (List<Trains>)formatter.Deserialize(stream);
                    stream.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: "+ex.Message);
                Console.ReadKey();
            } 
            return train;    
        }

    }
}
