﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RRS.EntityLayer;
using RRS.ExceptionLayer;
using RRS.BusinessLogicLayer;
namespace RRS.PresentationLayer
{
    class UserInterface
    {
        /***************************Main Menu Driven******************************/
        static void Main()
        {
            try
            {
                int choice = 0;
                do
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("*********************************************************************************************************************************");
                    Console.WriteLine("                                                   Railway Reservation System       ");
                    Console.WriteLine("*********************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("1: Add  Train:");
                    Console.WriteLine("2: View Train");
                    Console.WriteLine("3: Search Train");
                    Console.WriteLine("4: About");
                    Console.WriteLine("5: Exit");
                    Console.WriteLine("Enter your choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            if (TrainLogic.AddTrain_BLL(AddTrain_PL()))
                            {
                                Console.WriteLine("Train detail added successfully!!");
                            }
                            else
                                throw new TrainExceptions("Error in adding train details");
                            break;
                        case 2:
                            GetAllTrain_PL();
                            break;
                        case 3:
                            SearchTrain_PL();
                            break;
                       
                        case 4:
                            AboutDeveloper();
                            break;
                        case 5:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Wrong choice!! try again");
                            break;
                    }
                    Console.Write("Press any key for continue!!...");
                    Console.ReadKey();
                    Console.Clear();
                } while (choice != 6);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Error: The enterd formate of data is not aproprite"+ex.Message);
                Console.ReadKey();
                Console.Clear();
                Main();
            }
            catch (TrainExceptions ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
        /******************adding Train details****************/
        public static Trains AddTrain_PL()
        {
            Trains train = new Trains();
            try
            {
                Console.WriteLine("Enter Train number:");
                train.TrainNumber = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the source city:");
                train.SourceCity =Console.ReadLine();
                Console.WriteLine("Enter the destination city:");
                train.DestinationCity = Console.ReadLine();
                Console.WriteLine("Enter the Date:");
                train.Date = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter the arrival time:");
                train.ArrivalTime = Console.ReadLine();
                Console.WriteLine("Enter the departure time:");
                train.DepartureTime = Console.ReadLine();
                Console.WriteLine("Enter the station name:");
                train.StationName = Console.ReadLine();
            }
            catch (FormatException)
            {
                Console.WriteLine("ERROR: The enterd formate of data is not aproprite");
                AddTrain_PL();
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: " + ex.Message);
            }
            
            return train;
        }

        /***************Display all trains details******************/
        public static void GetAllTrain_PL()
        {
            List<Trains> trains = new List<Trains>();
            trains = TrainLogic.GetAllTrains_BLL();
            try
            {
                if (trains != null)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("*****************Details about Trains*********************************************************************************************");
                    Console.WriteLine("TrainNo. |  SourceCity    |     DestinationCity     |     Date     |     ArrivalTime     |     DepartureTime     |     StationName");
                    Console.WriteLine("**********************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.White;
                    foreach (Trains train in trains)
                    {
                        Console.WriteLine(train.TrainNumber + "      |  " + train.SourceCity + "             " + train.DestinationCity + "             " +train.Date.ToShortDateString() + "             " +train.ArrivalTime + "             " +train.DepartureTime + "             " +train.StationName);
                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("**********************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    throw (new TrainExceptions("Error: No trains available !!"));
                }
            }
            catch (TrainExceptions ex){Console.WriteLine(ex.Message);}
            catch (Exception ex) { Console.WriteLine(ex.Message); }
        }

        /***************************Searching for a train*****************/
        public static void SearchTrain_PL()
        {
            Console.WriteLine("\nSearch train by giving (SourceCity/DestinationCity/Date)");
            Console.WriteLine("\nSource City:");
            string sourceCity = Console.ReadLine();
            Console.WriteLine("Destination City:");
            string destinationCity = Console.ReadLine();
            Console.WriteLine("Date:");
            DateTime date =DateTime.Parse(Console.ReadLine());
            
            List<Trains> trains = new List<Trains>();
            trains = TrainLogic.GetAllTrains_BLL();
           
            try
            {
                if (trains != null)
                {
                    List<Trains> searchTrain = trains.FindAll(e => (e.SourceCity.Equals(sourceCity) && e.DestinationCity.Equals(destinationCity) && e.Date == date)).ToList();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("*****************Details about Trains*********************************************************************************************");
                    Console.WriteLine("TrainNo. |  SourceCity    |     DestinationCity     |     Date     |     ArrivalTime     |     DepartureTime     |     StationName");
                    Console.WriteLine("**********************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.White;
                    foreach (Trains train in searchTrain)
                    {
                        Console.WriteLine(train.TrainNumber + "      |  " + train.SourceCity + "             " + train.DestinationCity + "             " + train.Date.ToShortDateString() + "             " + train.ArrivalTime + "             " + train.DepartureTime + "             " + train.StationName);
                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("**********************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    throw (new TrainExceptions("Error: No trains available !!"));
                }
            }
            catch (TrainExceptions ex) { Console.WriteLine(ex.Message); }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
        }

        /*********************About developer**************/
        public static void AboutDeveloper()
        {

            Console.BackgroundColor = ConsoleColor.Blue;
            Console.WriteLine("************************************************************");
            Console.WriteLine("****************About Application Developer*****************");
            Console.WriteLine("************************************************************");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.BackgroundColor = ConsoleColor.White;
            Console.WriteLine("Project:          Railway Reservation System               .");
            Console.WriteLine("Group 1.:         Deepak Singh, Abhishek Malik             .");
            Console.WriteLine("Job:              Software Associate/Analyst               .");
            Console.WriteLine("Company:          Capgemini Ltd.,Pvt.                      .");
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.WriteLine("************************************************************");
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Black;
        }
    }
}
