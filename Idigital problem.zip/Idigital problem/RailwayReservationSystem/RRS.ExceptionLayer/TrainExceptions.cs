﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RRS.ExceptionLayer
{
    public class TrainExceptions:ApplicationException
    {
       public  TrainExceptions(string error):base(error)
        {

        }
    }
}
